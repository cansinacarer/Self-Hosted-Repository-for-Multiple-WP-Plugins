<?php
/*
   Plugin Name: Second Plugin
   Plugin URI:  https://github.com/cansinacarer/WP-Multi-Plugin-Repository/
   Description: Second test plugin to demo wp-plugin-auto-update script
   Version: 1.3
   Author: Cansın Çağan Acarer
   Author URI: http://www.35pixel.com
   License: GPL2

   Copyright 2011 Plugin Author (email : user@example.com)

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License, version 2, as
   published by the Free Software Foundation.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

//define('DEBUG', false);

if (!class_exists('WpPluginAutoUpdate')) {
    require('inc/updates.php');
}

$second_plugin_auto_update = new WpPluginAutoUpdate('http://www.35pixel.com/api/v1/wp-updates/', 'stable', basename(dirname(__FILE__)));

// Take over the update check
add_filter('pre_set_site_transient_update_plugins', array($second_plugin_auto_update, 'check_for_plugin_update'));

// Take over the Plugin info screen
add_filter('plugins_api', array($second_plugin_auto_update, 'plugins_api_call'), 10, 3);
